﻿using Hahn.ApplicatonProcess.December2020.Data.DbContexts;
using Hahn.ApplicatonProcess.December2020.Domain.DataAccess.Repository;
using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data.Repository
{
    class ApplicantRepository : IApplicantRepository
    {
        private readonly IApplicationProcessDbContext applicationProcessDbContext;
        public ApplicantRepository(IApplicationProcessDbContext applicationProcessDbContext)
        {
            this.applicationProcessDbContext = applicationProcessDbContext;
        }

        public async Task DeleteAsync(Applicant applicant)
        {
            HandleModified(applicant, EntityState.Deleted);

            await applicationProcessDbContext.SaveChangesAsync();
        }

        public async Task InsertAsync(Applicant applicant)
        {
            applicationProcessDbContext.Entry(applicant).State = EntityState.Added;
            applicationProcessDbContext.Applicant.Add(applicant);

            await applicationProcessDbContext.SaveChangesAsync();
        }

        public async Task UpdateAsync(Applicant applicant)
        {
            HandleModified(applicant, EntityState.Modified);
            await applicationProcessDbContext.SaveChangesAsync();
        }

        public async Task<List<Applicant>> SearchAsync(ApplicantRepositorySearchRequestDto applicantRepositorySearchRequestDto)
        {
            var query = applicationProcessDbContext.Applicant.AsNoTracking().AsQueryable();

            if (applicantRepositorySearchRequestDto != null)
            {
                if (applicantRepositorySearchRequestDto.ID.HasValue)
                {
                    query = query.Where(x => x.ID.Equals(applicantRepositorySearchRequestDto.ID));
                }
            }

            return await query.ToListAsync();
        }

        private void HandleModified(Applicant applicant, EntityState newState)
        {
            if (applicationProcessDbContext.Entry(applicant).State != EntityState.Detached)
            {
                applicationProcessDbContext.Entry(applicant).State = EntityState.Detached;
            }
            applicationProcessDbContext.Entry(applicant).State = newState;
        }
    }
}
