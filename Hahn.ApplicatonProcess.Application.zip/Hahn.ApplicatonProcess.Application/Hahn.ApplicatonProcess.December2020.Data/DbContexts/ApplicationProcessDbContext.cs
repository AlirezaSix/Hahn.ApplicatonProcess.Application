﻿using Hahn.ApplicatonProcess.December2020.Domain.Model;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hahn.ApplicatonProcess.December2020.Data.DbContexts
{
    class ApplicationProcessDbContext : DbContext, IApplicationProcessDbContext
    {
        public ApplicationProcessDbContext(DbContextOptions<ApplicationProcessDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }

        public DbSet<Applicant> Applicant { get; set; }
    }
}
