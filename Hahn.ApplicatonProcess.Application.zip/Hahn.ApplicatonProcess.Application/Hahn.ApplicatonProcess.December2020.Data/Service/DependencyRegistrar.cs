﻿using Hahn.ApplicatonProcess.December2020.Data.DbContexts;
using Hahn.ApplicatonProcess.December2020.Data.Repository;
using Hahn.ApplicatonProcess.December2020.Domain.DataAccess.Repository;
using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.DI;
using Hahn.ApplicatonProcess.December2020.Domain.Service;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("Hahn.ApplicatonProcess.December2020.Web")]
namespace Hahn.ApplicatonProcess.December2020.Data.Service
{
    class DependencyRegistrar : IDependencyRegistrar
    {
        public int Order => 1;

        public void Register(IServiceCollection services)
        {
            services.AddDbContext<ApplicationProcessDbContext>(opt => opt.UseInMemoryDatabase("ApplicationProcessDatabase"));
            services.AddTransient<IApplicationProcessDbContext, ApplicationProcessDbContext>();
            services.AddTransient<IApplicantRepository, ApplicantRepository>();
        }
    }
}
