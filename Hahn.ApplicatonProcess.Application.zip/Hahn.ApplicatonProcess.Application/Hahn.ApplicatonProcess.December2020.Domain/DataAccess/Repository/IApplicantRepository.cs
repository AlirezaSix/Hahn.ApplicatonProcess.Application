﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.DataAccess.Repository
{
    public interface IApplicantRepository
    {
        Task InsertAsync(Applicant applicant);
        Task UpdateAsync(Applicant applicant);
        Task DeleteAsync(Applicant applicant);
        Task<List<Applicant>> SearchAsync(ApplicantRepositorySearchRequestDto applicantRepositorySearchRequestDto);
    }
}
