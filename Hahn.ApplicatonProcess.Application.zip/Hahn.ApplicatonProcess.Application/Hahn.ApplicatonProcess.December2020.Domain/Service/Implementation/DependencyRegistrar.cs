﻿using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.DI;
using Microsoft.Extensions.DependencyInjection;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("Hahn.ApplicatonProcess.December2020.Web")]
namespace Hahn.ApplicatonProcess.December2020.Domain.Service.Implementation
{
    class DependencyRegistrar : IDependencyRegistrar
    {
        public DependencyRegistrar()
        {

        }

        public int Order => 2;

        public void Register(IServiceCollection services)
        {
            services.AddTransient<IHttpService, HttpService>();
            services.AddTransient<ICountryValidatorService, CountryValidatorService>();
            services.AddTransient<IAppliacantService, AppliacantService>();

        }
    }
}
