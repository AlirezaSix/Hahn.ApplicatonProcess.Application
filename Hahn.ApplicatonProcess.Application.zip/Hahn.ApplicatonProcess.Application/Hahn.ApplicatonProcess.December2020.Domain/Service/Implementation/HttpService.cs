﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Http;
using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using Hahn.ApplicatonProcess.December2020.Domain.Mapping;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Service.Implementation
{
    internal class HttpService : IHttpService
    {
        public TResult Post<TResult, TParam>(HttpPostRequestDto<TParam> request)
        {
            if (request == null)
            {
                throw new Exception("Invalid Request.");
            }
            if (!request.Url.HasValue())
            {
                throw new Exception("Url cannot be empty.");
            }

            return Request<TResult, TParam>(request.Url, request.Token, HttpRequestType.Post, request.Param);
        }
        public TResult Get<TResult>(HttpGetRequestDto request)
        {
            if (request == null)
            {
                throw new Exception("Invalid Request.");
            }
            if (!request.Url.HasValue())
            {
                throw new Exception("Url cannot be empty.");
            }

            return Request<TResult, object>(request.Url, request.Token, HttpRequestType.Get, null);
        }
        private TResult Request<TResult, TParam>(string url, string token, HttpRequestType httpRequestType, TParam param)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("User-Agent", "PayamGostar Http Request");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (token.HasValue())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }

                Task<HttpResponseMessage> response = null;
                switch (httpRequestType)
                {
                    case HttpRequestType.Get:
                        response = Task.Run(() => client.GetAsync(url));
                        break;
                    case HttpRequestType.Post:
                        var requestParam = string.Empty;
                        if (param != null && !param.Equals(default(TParam)))
                        {
                            requestParam = JsonConvert.SerializeObject(param);
                        }
                        response = Task.Run(() => client.PostAsync(url.TrimEnd('/'), new StringContent(requestParam, Encoding.UTF8, "application/json")));
                        break;
                }

                response.Wait();

                var resp = response.GetAwaiter().GetResult();

                if (!resp.StatusCode.Equals(System.Net.HttpStatusCode.OK))
                {
                    throw new Exception("Request did not return success status.");
                }

                return JsonConvert.DeserializeObject<TResult>(resp.Content.ReadAsStringAsync().GetAwaiter().GetResult());
            }
        }
    }
}
