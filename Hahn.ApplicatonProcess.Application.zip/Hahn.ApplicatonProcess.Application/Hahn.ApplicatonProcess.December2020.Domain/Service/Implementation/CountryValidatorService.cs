﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Http;
using System.Collections.Generic;
using System.Linq;

namespace Hahn.ApplicatonProcess.December2020.Domain.Service.Implementation
{
    class CountryValidatorService : ICountryValidatorService
    {
        private readonly IHttpService httpService;

        public CountryValidatorService(IHttpService httpService)
        {
            this.httpService = httpService;

        }
        public bool Exist(string country)
        {
            try
            {
                return httpService.Get<List<CountryOfOriginDto>>(new HttpGetRequestDto()
                {
                    Token = null,
                    Url = $"{Constant.CountryOfOriginValidatorUrl}{country}?fullText=true"
                })?.Any() ?? false;
            }
            catch
            {
                return false;
            }
        }
    }
}
