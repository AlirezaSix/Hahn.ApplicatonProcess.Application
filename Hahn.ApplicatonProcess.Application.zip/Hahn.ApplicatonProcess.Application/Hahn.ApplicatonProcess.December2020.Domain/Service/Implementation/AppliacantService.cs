﻿using Hahn.ApplicatonProcess.December2020.Domain.DataAccess.Repository;
using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using Hahn.ApplicatonProcess.December2020.Domain.Exceptions;
using Hahn.ApplicatonProcess.December2020.Domain.Mapping;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Transactions;

[assembly: InternalsVisibleTo("Hahn.ApplicatonProcess.Application.UnitTest")]
namespace Hahn.ApplicatonProcess.December2020.Domain.Service.Implementation
{
    class AppliacantService : IAppliacantService
    {
        private readonly IApplicantRepository applicantRepository;
        private readonly ICountryValidatorService countryValidatorService;

        public AppliacantService(
            IApplicantRepository applicantRepository,
            ICountryValidatorService countryValidatorService)
        {
            this.applicantRepository = applicantRepository;
            this.countryValidatorService = countryValidatorService;
        }

        public async Task<bool> DeleteAsync(ApplicantDeleteRequestDto applicantDeleteRequestDto)
        {
            Validate(applicantDeleteRequestDto);

            var priorApplicant = await applicantRepository.SearchAsync(applicantDeleteRequestDto.ToSearchRepository()).FirstOrDefaultAsync();

            if (priorApplicant == null)
            {
                throw new NotFoundException(nameof(Applicant));
            }

            await DeleteAsync(priorApplicant);
            return true;
        }

        public async Task<ApplicantDto> GetByIdAsync(int id)
        {
            return (await applicantRepository.SearchAsync(id.ToSearchRepository()).FirstOrDefaultAsync()).ToDto();
        }

        public async Task<ApplicantDto> InsertAsync(ApplicantInsertRequestDto applicantInsertRequestDto)
        {
            ValidateChangeRequest<Applicant>(applicantInsertRequestDto);
            var model = applicantInsertRequestDto.ToModel();
            await InsertAsync(model);
            return model.ToDto();
        }

        public async Task<ApplicantDto> UpdateAsync(ApplicantUpdateRequestDto applicantUpdateRequestDto)
        {
            Validate(applicantUpdateRequestDto);

            if (applicantUpdateRequestDto.ID <= 0)
            {
                throw new InvalidPropertyValueException(nameof(ApplicantUpdateRequestDto), nameof(ApplicantUpdateRequestDto.ID));
            }

            ValidateChangeRequest<Applicant>(applicantUpdateRequestDto);

            var priorApplicants = await applicantRepository.SearchAsync(applicantUpdateRequestDto.ToSearchRepository());

            if (!priorApplicants?.Any() ?? true)
            {
                throw new NotFoundException(nameof(Applicant));
            }

            var model = applicantUpdateRequestDto.ToModel();
            await UpdateAsync(model);
            return model.ToDto();
        }

        public async Task<IEnumerable<ApplicantDto>> GetAsync()
        {
            return (await applicantRepository.SearchAsync(null)).ToDto();
        }

        private void Validate<TEntity>(TEntity entity) where TEntity : class, new()
        {
            if (entity == default(TEntity))
            {
                throw new Exceptions.NullReferenceException(nameof(Applicant));
            }
        }

        private void ValidateChangeRequest<TEntity>(ApplicantChangeRequestDto request)
        {
            Validate(request);

            if (request.Name.Length < 5)
            {
                throw new InvalidPropertyValueException(typeof(TEntity).Name, nameof(ApplicantChangeRequestDto.Name));
            }

            if (request.FamilyName.Length < 5)
            {
                throw new InvalidPropertyValueException(typeof(TEntity).Name, nameof(ApplicantChangeRequestDto.FamilyName));
            }

            if (request.Address.Length < 10)
            {
                throw new InvalidPropertyValueException(typeof(TEntity).Name, nameof(ApplicantChangeRequestDto.Address));
            }

            if (request.Age < 20 || request.Age > 60)
            {
                throw new InvalidPropertyValueException(typeof(TEntity).Name, nameof(ApplicantChangeRequestDto.Age));
            }

            if (!request.EMailAddress.IsValidEmail())
            {
                throw new InvalidPropertyValueException(typeof(TEntity).Name, nameof(ApplicantChangeRequestDto.EMailAddress));
            }

            if (!countryValidatorService.Exist(request.CountryOfOrigin))
            {
                throw new InvalidPropertyValueException(typeof(TEntity).Name, nameof(ApplicantChangeRequestDto.CountryOfOrigin));
            }
        }

        private async Task InsertAsync(Applicant applicant)
        {
            using (var tran = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {
                    await applicantRepository.InsertAsync(applicant);
                    tran.Complete();
                }
                catch (Exception ex)
                {
                    throw new RepositoryException(ex.Message);
                }
            }
        }

        private async Task UpdateAsync(Applicant applicant)
        {
            using (var tran = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {
                    await applicantRepository.UpdateAsync(applicant);
                    tran.Complete();
                }
                catch (Exception ex)
                {
                    throw new RepositoryException(ex.Message);
                }
            }
        }

        private async Task DeleteAsync(Applicant applicant)
        {
            using (var tran = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {
                    await applicantRepository.DeleteAsync(applicant);
                    tran.Complete();
                }
                catch (Exception ex)
                {
                    throw new RepositoryException(ex.Message);
                }
            }
        }
    }
}
