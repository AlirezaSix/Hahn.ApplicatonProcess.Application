﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Service
{
    public interface IAppliacantService
    {
        Task<ApplicantDto> InsertAsync(ApplicantInsertRequestDto applicantInsertRequestDto);
        Task<ApplicantDto> UpdateAsync(ApplicantUpdateRequestDto applicantUpdateRequestDto);
        Task<ApplicantDto> GetByIdAsync(int id);
        Task<IEnumerable<ApplicantDto>> GetAsync();
        Task<bool> DeleteAsync(ApplicantDeleteRequestDto applicantDeleteRequestDto);
    }
}
