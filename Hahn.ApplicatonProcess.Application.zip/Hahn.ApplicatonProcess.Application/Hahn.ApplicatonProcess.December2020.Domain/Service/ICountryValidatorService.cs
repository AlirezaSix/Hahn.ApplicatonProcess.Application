﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Service
{
    public interface ICountryValidatorService
    {
        bool Exist(string country);
    }
}
