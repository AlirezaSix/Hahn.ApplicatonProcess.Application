﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Http;

namespace Hahn.ApplicatonProcess.December2020.Domain.Service
{
    public interface IHttpService
    {      
        TResult Post<TResult, TParam>(HttpPostRequestDto<TParam> request);
        TResult Get<TResult>(HttpGetRequestDto request);
    }
}
