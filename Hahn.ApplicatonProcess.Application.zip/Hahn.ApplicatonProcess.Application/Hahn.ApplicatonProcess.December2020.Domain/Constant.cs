﻿namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public class Constant
    {
        public static readonly string CountryOfOriginValidatorUrl = "https://restcountries.eu/rest/v2/name/";
    }
}
