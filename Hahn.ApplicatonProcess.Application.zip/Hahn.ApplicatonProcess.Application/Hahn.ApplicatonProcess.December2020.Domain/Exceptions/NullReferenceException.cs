﻿using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using System;

namespace Hahn.ApplicatonProcess.December2020.Domain.Exceptions
{
    public class NullReferenceException : Exception
    {
        public ErrorType ErrorType => ErrorType.NullReference;
        public NullReferenceException(string entityName)
            : base(entityName)
        {
        }
    }
}
