﻿using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using System;

namespace Hahn.ApplicatonProcess.December2020.Domain.Exceptions
{
    public class NotFoundException : Exception
    {
        public ErrorType ErrorType => ErrorType.NotFound;
        public NotFoundException(string entityName)
    : base(entityName)
        {
        }
    }
}
