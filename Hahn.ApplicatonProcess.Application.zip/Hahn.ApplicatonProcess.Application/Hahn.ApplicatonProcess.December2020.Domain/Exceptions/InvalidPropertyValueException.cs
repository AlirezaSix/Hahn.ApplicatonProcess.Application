﻿using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using System;

namespace Hahn.ApplicatonProcess.December2020.Domain.Exceptions
{
    public class InvalidPropertyValueException : Exception
    {
        public ErrorType ErrorType => ErrorType.InvalidPropertyValue;
        public InvalidPropertyValueException(string entityName, string propertyName)
            : base($"{entityName}_{propertyName}")
        {
        }
    }
}
