﻿using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using System;

namespace Hahn.ApplicatonProcess.December2020.Domain.Exceptions
{
    public class RepositoryException : Exception
    {
        public ErrorType ErrorType => ErrorType.ErrorOccured;
        public RepositoryException(string message)
            : base(message)
        {
        }
    }
}
