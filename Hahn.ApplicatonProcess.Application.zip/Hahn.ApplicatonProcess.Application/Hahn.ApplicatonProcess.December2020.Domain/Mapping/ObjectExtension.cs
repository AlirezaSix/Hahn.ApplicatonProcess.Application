﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Mapping
{
    public static class ObjectExtension
    {
        public static bool HasValue(this string value)
        {
            return !(string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value));
        }

        public static bool IsValidEmail(this string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }
}
