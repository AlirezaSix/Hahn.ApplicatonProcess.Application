﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using System.Collections.Generic;
using System.Linq;

namespace Hahn.ApplicatonProcess.December2020.Domain.Mapping
{
    internal static class ApplicantMapper
    {
        internal static ApplicantRepositorySearchRequestDto ToSearchRepository(this ApplicantUpdateRequestDto applicantChangeRequestDto)
        {
            return new ApplicantRepositorySearchRequestDto()
            {
                ID = applicantChangeRequestDto.ID
            };
        }

        internal static ApplicantRepositorySearchRequestDto ToSearchRepository(this ApplicantDeleteRequestDto applicantChangeRequestDto)
        {
            return new ApplicantRepositorySearchRequestDto()
            {
                ID = applicantChangeRequestDto.ID
            };
        }

        internal static ApplicantRepositorySearchRequestDto ToSearchRepository(this int id)
        {
            return new ApplicantRepositorySearchRequestDto()
            {
                ID = id
            };
        }


        internal static Applicant ToModel(this ApplicantInsertRequestDto applicantChangeRequestDto)
        {
            return new Applicant()
            {
                Address = applicantChangeRequestDto.Address,
                Age = applicantChangeRequestDto.Age,
                CountryOfOrigin = applicantChangeRequestDto.CountryOfOrigin,
                EMailAddress = applicantChangeRequestDto.EMailAddress,
                FamilyName = applicantChangeRequestDto.FamilyName,
                Hired = applicantChangeRequestDto.Hired ?? false,
                Name = applicantChangeRequestDto.Name
            };
        }

        internal static Applicant ToModel(this ApplicantUpdateRequestDto applicantChangeRequestDto)
        {
            return new Applicant()
            {
                Address = applicantChangeRequestDto.Address,
                Age = applicantChangeRequestDto.Age,
                CountryOfOrigin = applicantChangeRequestDto.CountryOfOrigin,
                EMailAddress = applicantChangeRequestDto.EMailAddress,
                FamilyName = applicantChangeRequestDto.FamilyName,
                Hired = applicantChangeRequestDto.Hired ?? false,
                Name = applicantChangeRequestDto.Name,
                ID = applicantChangeRequestDto.ID
            };
        }

        internal static IEnumerable<ApplicantDto> ToDto(this IEnumerable<Applicant> model)
        {
            if(model?.Any() ?? false)
            {
                return (from x in model select x.ToDto());
            }

            return new List<ApplicantDto>();
        }

        internal static ApplicantDto ToDto(this Applicant model)
        {
            if(model == null)
            {
                return null;
            }

            return new ApplicantDto()
            {
                Address = model.Address,
                Age = model.Age,
                CountryOfOrigin = model.CountryOfOrigin,
                EMailAddress = model.EMailAddress,
                FamilyName = model.FamilyName,
                Hired = model.Hired,
                Name = model.Name,
                ID = model.ID
            };
        }
    }
}
