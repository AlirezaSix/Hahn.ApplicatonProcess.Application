﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Mapping
{
    public static class AsyncExtension
    {
        public static async Task<TEntity> FirstOrDefaultAsync<TEntity>(this Task<List<TEntity>> source)
        {
            var toRet = await source;
            return toRet.FirstOrDefault();
        }
        public static async Task<bool> AnyAsync<TEntity>(this Task<List<TEntity>> source)
        {
            var toRet = await source;
            return toRet?.Any() ?? false;
        }
        public static async Task<IEnumerable<TResult>> SelectAsync<TEntity, TResult>(this Task<List<TEntity>> source, Func<TEntity, TResult> selector)
        {
            var toRet = await source;
            return toRet?.Select(selector) ?? new List<TResult>();
        }
        public static async Task<IEnumerable<TResult>> SelectManyAsync<TEntity, TResult>(this Task<List<TEntity>> source, Func<TEntity, IEnumerable<TResult>> selector)
        {
            var toRet = await source;
            return toRet?.SelectMany(selector) ?? new List<TResult>();
        }
    }
}
