﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant
{

    public class ApplicantInsertRequestDto : ApplicantChangeRequestDto
    {
    }
}
