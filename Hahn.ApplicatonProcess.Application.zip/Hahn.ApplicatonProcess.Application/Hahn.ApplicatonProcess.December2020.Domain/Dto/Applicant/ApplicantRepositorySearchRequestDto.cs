﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant
{
    public class ApplicantRepositorySearchRequestDto
    {
        public int? ID { get; set; }
    }
}
