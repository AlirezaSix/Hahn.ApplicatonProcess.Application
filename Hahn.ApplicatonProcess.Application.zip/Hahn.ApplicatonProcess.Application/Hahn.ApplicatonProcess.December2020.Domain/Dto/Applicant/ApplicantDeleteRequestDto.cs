﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant
{
    public class ApplicantDeleteRequestDto
    {
        public int ID { get; set; }
    }
}
