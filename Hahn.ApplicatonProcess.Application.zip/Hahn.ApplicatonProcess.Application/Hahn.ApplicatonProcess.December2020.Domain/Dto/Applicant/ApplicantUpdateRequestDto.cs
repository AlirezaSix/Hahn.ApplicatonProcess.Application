﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant
{
    public class ApplicantUpdateRequestDto : ApplicantChangeRequestDto
    {
        public int ID { get; set; }
    }
}
