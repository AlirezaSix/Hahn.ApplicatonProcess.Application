﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Dto.Http
{
    public class HttpGetRequestDto
    {
        public string Url { get; set; }
        public string Token { get; set; }
    }
}
