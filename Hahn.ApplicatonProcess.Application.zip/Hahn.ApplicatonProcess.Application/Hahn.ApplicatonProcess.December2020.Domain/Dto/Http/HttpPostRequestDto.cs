﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Dto.Http
{
    public class HttpPostRequestDto<TParam>
    {
        public string Url { get; set; }
        public string Token { get; set; }
        public TParam Param { get; set; }
    }
}
