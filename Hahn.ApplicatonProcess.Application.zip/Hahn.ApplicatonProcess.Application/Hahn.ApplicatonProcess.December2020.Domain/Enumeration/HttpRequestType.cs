﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Enumeration
{
    public enum HttpRequestType
    {
        Get = 1,
        Post = 2
    }
}
