﻿namespace Hahn.ApplicatonProcess.December2020.Domain.Enumeration
{
    public enum ErrorType
    {
        InvalidRequest = 1,
        NullReference,
        InvalidPropertyValue,
        NotFound,
        ErrorOccured,
        UnHandledException
    }
}
