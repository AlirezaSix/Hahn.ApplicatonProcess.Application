﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hahn.ApplicatonProcess.December2020.Domain.Model
{
    public class Applicant
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [StringLength(int.MaxValue, MinimumLength = 5)]
        public string Name { get; set; }

        [StringLength(int.MaxValue, MinimumLength = 5)]
        public string FamilyName { get; set; }

        [StringLength(int.MaxValue, MinimumLength = 10)]
        public string Address { get; set; }
        public string CountryOfOrigin { get; set; }

        [EmailAddress]
        public string EMailAddress { get; set; }

        [Range(20, 60)]
        public int Age { get; set; }
        public bool Hired { get; set; }
    }
}
