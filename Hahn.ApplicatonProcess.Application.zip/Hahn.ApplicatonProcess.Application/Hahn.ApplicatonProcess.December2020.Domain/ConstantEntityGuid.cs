﻿using System;

namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public class ConstantEntityGuid
    {
        public static Guid ApplicantId // {174A5064-4E1C-47AB-9620-938B6DE8F485}
        {
            get { return new Guid(0x174a5064, 0x4e1c, 0x47ab, 0x96, 0x20, 0x93, 0x8b, 0x6d, 0xe8, 0xf4, 0x85); }
        }
    }
}
