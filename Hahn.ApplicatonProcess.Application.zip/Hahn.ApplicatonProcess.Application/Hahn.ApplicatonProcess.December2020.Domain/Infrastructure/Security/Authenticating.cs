﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.Security
{
    public class Authenticating
    {
        private static readonly string privateKey = "1fghj6k8urwqyoip";
        public static string DesEncryptId(Guid key, int plainText)
        {
            cTripleDES cT = new cTripleDES(key.ToByteArray(), Encoding.ASCII.GetBytes(privateKey));
            string str = cT.Encrypt(plainText.ToString());
            return str;
        }
        public static int DesDecryptId(Guid key, string plainText)
        {
            cTripleDES cT = new cTripleDES(key.ToByteArray(), Encoding.ASCII.GetBytes(privateKey));
            string str = cT.Decrypt(plainText);
            return int.Parse(str);
        }
    }
}
