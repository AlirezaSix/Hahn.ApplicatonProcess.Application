﻿using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.Security;
using System;

namespace Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.JsonConverters
{
    public abstract class IntEncryptedJsonConverter : JsonConverter<int>
    {
        protected abstract Guid EntityGuid { get; }

        public override string Write(int value)
        {
            return Authenticating.DesEncryptId(EntityGuid, (int)value);
        }

        public override int Read(string value)
        {
            if (string.IsNullOrEmpty(value))
                return default(int);

            return Authenticating.DesDecryptId(EntityGuid, value);
        }
    }
}
