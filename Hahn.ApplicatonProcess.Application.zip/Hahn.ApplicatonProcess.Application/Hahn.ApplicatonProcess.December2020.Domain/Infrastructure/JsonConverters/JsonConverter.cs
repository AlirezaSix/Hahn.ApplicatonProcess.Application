﻿using Newtonsoft.Json;
using System;

namespace Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.JsonConverters
{
    public abstract class JsonConverter<T> : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(T);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.Value == null)
                return (object)this.Read(string.Empty);

            return (object)this.Read(reader.Value.ToString());
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            writer.WriteValue(this.Write((T)value));
        }

        public abstract string Write(T value);
        public abstract T Read(string value);
    }
}
