﻿using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.DI
{
    public interface IDependencyRegistrar
    {
        int Order { get; }

        void Register(IServiceCollection serviceDescriptors);
    }
}
