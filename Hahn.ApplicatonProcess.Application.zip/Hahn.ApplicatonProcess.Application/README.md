# Code Challange Application

# project has been written with vs2019 and vscode

# Server Side Running Instruction 
open solution (Sln file) in Visual Studio
run application with kestrel in debug mode(it will open web app in http://localhost:5001)
the swagger will be load as a default page
I inspired by microsoft spa utilities do, I write simple code to install and run client side application.
this code will be executed with method RunAurelia in AureliaHelper.cs class which be called in Configure method of Startup class.
this helper method tested with cmd.exe in windows 10 so, if you do not want to use it please comment mentioned method and continue instruction.

# Client Side Running Instruction (directory is 'Hahn.ApplicatonProcess.December2020.Client' in root)
run following command 
    1. run 'npm install aurelia-cli -g' if aurelia cli not installed
    1. `npm install`
    2. `au run --open`
client side has been configured to read base_url of apis from `Hahn.ApplicatonProcess.December2020.Client\config\environment.json` file .
the default value is `https://localhost:5001/api/V1` which is default url of server side application

list page is a default page. you can navigate via left side menu to list and add applicant page or simply modify or delete application of list


# Unit Test Project (Hahn.ApplicatonProcess.Application.UnitTest in root)
I just added simple unit test for just one method (in the real world I usually use TDD)