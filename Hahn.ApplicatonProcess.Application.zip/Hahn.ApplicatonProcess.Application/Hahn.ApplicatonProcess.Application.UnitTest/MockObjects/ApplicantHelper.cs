﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;

namespace Hahn.ApplicatonProcess.Application.UnitTest.MockObjects
{
    internal class ApplicantHelper
    {
        internal static ApplicantUpdateRequestDto GetApplicant(int id = 0, string name = "", string family = "", string address = "", string countryOfOrigin = "", int age = 0, bool hired = true, string emailAddress = "")
        {
            return new ApplicantUpdateRequestDto()
            {
                Address = address,
                Age = age,
                CountryOfOrigin = countryOfOrigin,
                EMailAddress = emailAddress,
                FamilyName = family,
                Hired = hired,
                ID = id,
                Name = name
            };
        }
    }
}
