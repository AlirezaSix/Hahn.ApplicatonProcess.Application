using Hahn.ApplicatonProcess.Application.UnitTest.MockObjects;
using Hahn.ApplicatonProcess.December2020.Domain.DataAccess.Repository;
using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using Hahn.ApplicatonProcess.December2020.Domain.Service;
using Hahn.ApplicatonProcess.December2020.Domain.Service.Implementation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.Application.UnitTest
{
    [TestCategory("ApplicationService")]
    [TestCategory("UpdateAsync")]
    [TestClass]
    public class UpdateAsyncTest
    {
        [TestMethod]
        public async Task NullRequest()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(null);
            }
            catch (December2020.Domain.Exceptions.NullReferenceException ex)
            {
                Assert.AreEqual(ex.Message, nameof(Applicant));
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task EmptyRequest()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(new ApplicantUpdateRequestDto());
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(ApplicantUpdateRequestDto)}_{nameof(ApplicantUpdateRequestDto.ID)}");            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task InvalidId()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 0));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(ApplicantUpdateRequestDto)}_{nameof(ApplicantUpdateRequestDto.ID)}");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task InvalidName()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "ali"));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(Applicant)}_{nameof(ApplicantChangeRequestDto.Name)}");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task InvalidFamilyName()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yad"));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(Applicant)}_{nameof(ApplicantChangeRequestDto.FamilyName)}");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task InvalidAddress()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "fake"));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(Applicant)}_{nameof(ApplicantChangeRequestDto.Address)}");
            }
            catch
            {
                Assert.Fail();
            }
        }
        [TestMethod]
        public async Task InvalidAge()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "justsomefakeaddresstofill", age: 19));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(Applicant)}_{nameof(ApplicantChangeRequestDto.Age)}");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task InvalidEmailAddress()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "justsomefakeaddresstofill", age: 22, emailAddress: "sc"));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(Applicant)}_{nameof(ApplicantChangeRequestDto.EMailAddress)}");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task InvalidCountryOfOrigin()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "justsomefakeaddresstofill", age: 22, emailAddress: "alireza.yadegary@gmail.com"));
            }
            catch (December2020.Domain.Exceptions.InvalidPropertyValueException ex)
            {
                Assert.AreEqual(ex.Message, $"{nameof(Applicant)}_{nameof(ApplicantChangeRequestDto.CountryOfOrigin)}");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task NotFoundUser()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            countryValidatorService.Setup(x => x.Exist(It.IsAny<string>())).Returns(true);
            applicantRepository.Setup(x => x.SearchAsync(It.IsAny<ApplicantRepositorySearchRequestDto>())).Returns(Task.FromResult<List<Applicant>>(null));

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "justsomefakeaddresstofill", age: 22, emailAddress: "alireza.yadegary@gmail.com", countryOfOrigin: "ss"));
            }
            catch (December2020.Domain.Exceptions.NotFoundException ex)
            {
                Assert.AreEqual(ex.Message, nameof(Applicant));
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task RepositoryException()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            countryValidatorService.Setup(x => x.Exist(It.IsAny<string>())).Returns(true);
            applicantRepository.Setup(x => x.SearchAsync(It.IsAny<ApplicantRepositorySearchRequestDto>())).Returns(Task.FromResult<List<Applicant>>(new List<Applicant>()
            {
                new Applicant()
                {
                    ID = 1,
                    Address = "justsomefakeaddresstofill",
                    Age = 22,
                    CountryOfOrigin = "ss",
                    EMailAddress = "alireza.yadegary@gmail.com",
                    FamilyName = "yadegari",
                    Hired = true,
                    Name = "alireza"
                }
            }));

            applicantRepository.Setup(x => x.UpdateAsync(It.IsAny<Applicant>())).Throws(new Exception("some errors"));

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "justsomefakeaddresstofill", age: 22, emailAddress: "alireza.yadegary@gmail.com", countryOfOrigin: "ss"));
            }
            catch (December2020.Domain.Exceptions.RepositoryException ex)
            {
                Assert.AreEqual(ex.Message, "some errors");
            }
            catch
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        public async Task RightSenario()
        {
            Mock<IApplicantRepository> applicantRepository = new Mock<IApplicantRepository>();
            Mock<ICountryValidatorService> countryValidatorService = new Mock<ICountryValidatorService>();

            countryValidatorService.Setup(x => x.Exist(It.IsAny<string>())).Returns(true);
            applicantRepository.Setup(x => x.SearchAsync(It.IsAny<ApplicantRepositorySearchRequestDto>())).Returns(Task.FromResult<List<Applicant>>(new List<Applicant>()
            {
                new Applicant()
                {
                    ID = 1,
                    Address = "justsomefakeaddresstofill",
                    Age = 22,
                    CountryOfOrigin = "ss",
                    EMailAddress = "alireza.yadegary@gmail.com",
                    FamilyName = "yadegari",
                    Hired = true,
                    Name = "alireza"
                }
            }));

            applicantRepository.Setup(x => x.UpdateAsync(It.IsAny<Applicant>()));

            var service = new AppliacantService(applicantRepository.Object, countryValidatorService.Object);

            try
            {
                var result = await service.UpdateAsync(ApplicantHelper.GetApplicant(id: 1, name: "alireza", family: "yadegari", address: "justsomefakeaddresstofill", age: 22, emailAddress: "alireza.yadegary@gmail.com", countryOfOrigin: "ss"));

                Assert.AreEqual(result.Address, "justsomefakeaddresstofill");
                Assert.AreEqual(result.Age, 22);
                Assert.AreEqual(result.CountryOfOrigin, "ss");
                Assert.AreEqual(result.EMailAddress, "alireza.yadegary@gmail.com");
                Assert.AreEqual(result.FamilyName, "yadegari");
                Assert.AreEqual(result.Hired, true);
                Assert.AreEqual(result.ID, 1);
                Assert.AreEqual(result.Name, "alireza");

            }
            catch
            {
                Assert.Fail();
            }
        }
    }
}
