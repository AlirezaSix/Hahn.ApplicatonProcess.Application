﻿using System.Diagnostics;
using System.IO;

namespace Hahn.ApplicatonProcess.December2020.Web.Helper
{
    internal class AureliaHelper
    {
        private static readonly string ClientAppDirectoryName = "Hahn.ApplicatonProcess.December2020.Client";
        private static readonly string NodeMuduleAppDirectoryName = "node_modules";
        internal static void RunAurelia()
        {
            Process p = new Process();
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = "cmd.exe";
            info.RedirectStandardInput = true;
            info.UseShellExecute = false;

            p.StartInfo = info;
            p.Start();

            using (StreamWriter sw = p.StandardInput)
            {
                if (sw.BaseStream.CanWrite)
                {
                    sw.WriteLine("cd ..");
                    sw.WriteLine($"cd ./{ClientAppDirectoryName}");

                    sw.WriteLine("npm install aurelia-cli -g");

                    sw.WriteLine("npm install -g webpack-dev-server");

                    if (!Directory.Exists(Path.Combine(Path.GetDirectoryName(Directory.GetCurrentDirectory()), ClientAppDirectoryName, NodeMuduleAppDirectoryName)))
                    {
                        sw.WriteLine("npm install");
                    }

                    sw.WriteLine("au run --open");
                }
            }
        }
    }
}
