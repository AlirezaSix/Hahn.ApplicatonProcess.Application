using Hahn.ApplicatonProcess.December2020.Web.Configuration;
using Hahn.ApplicatonProcess.December2020.Web.Helper;
using Hahn.ApplicatonProcess.December2020.Web.ModelBinders;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System;
using System.IO;
using System.Reflection;

namespace Hahn.ApplicatonProcess.December2020.Web
{

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.RegisterDependencyInjection();

            services.AddControllers(options =>
            {
                options.ModelBinderProviders.Insert(0, new ApplicantBinderProvider());

            }).AddNewtonsoftJson();

            services.AddCors(options =>
            {
                options.AddPolicy("ApplicationCorPolicies",
                                  builder =>
                                  {
                                      builder.WithOrigins("http://localhost:8080");
                                      builder.AllowAnyHeader();
                                      builder.AllowAnyMethod();
                                  });
            });

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Hahn.ApplicatonProcess.Application", Version = "v1" });

                c.MapType<int>(() => new OpenApiSchema
                {
                    Type = "string"
                });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Hahn.ApplicatonProcess.Application v1");
            });

            app.UseRequestResponseLogging();

            app.ConfigureCustomExceptionMiddleware();

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseCors("ApplicationCorPolicies");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            AureliaHelper.RunAurelia();
        }

    }
}
