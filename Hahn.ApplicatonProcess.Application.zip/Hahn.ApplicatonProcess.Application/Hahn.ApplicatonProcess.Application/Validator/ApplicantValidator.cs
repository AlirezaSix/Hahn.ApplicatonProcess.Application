﻿using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Domain.Service;
using Hahn.ApplicatonProcess.December2020.Web.ViewModel.V1.Applicant;

namespace Hahn.ApplicatonProcess.December2020.Web.Validator
{
    public class ApplicantValidator : AbstractValidator<InsertApplicantRequestViewModel>
    {
        public ApplicantValidator(ICountryValidatorService countryValidatorService)
        {
            RuleFor(x => x.Name).MinimumLength(5).WithMessage("name must has at least 5 charecters");
            RuleFor(x => x.FamilyName).MinimumLength(5).WithMessage("family must has at least 5 charecters");
            RuleFor(x => x.Address).MinimumLength(10).WithMessage("address must has at least 10 charecters");
            RuleFor(x => x.EMailAddress).NotEmpty().WithMessage("email address must be filled").EmailAddress().WithMessage("invalid email address format");
            RuleFor(x => x.Age).InclusiveBetween(20, 60).WithMessage("age must be between 20 and 60");
            RuleFor(x => x.CountryOfOrigin).Must(countryValidatorService.Exist).WithMessage("invalid country");
        }
    }
}
