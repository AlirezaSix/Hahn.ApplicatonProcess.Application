﻿namespace Hahn.ApplicatonProcess.December2020.Web.ViewModel.V1.Applicant
{
    public class UpdateApplicantRequestViewModel
    {
        /// <summary>
        /// the name of applicant
        /// </summary>
        /// <example>alireza</example>
        public string Name { get; set; }

        /// <summary>
        /// the family name of applicant
        /// </summary>
        /// <example>yadegari</example>
        public string FamilyName { get; set; }

        /// <summary>
        /// the address of applicant
        /// </summary>
        /// <example>firstpart,secpart,thiredpart,otherpart</example>
        public string Address { get; set; }

        /// <summary>
        /// the country of origin of applicant
        /// </summary>
        /// <example>aruba</example>
        public string CountryOfOrigin { get; set; }


        /// <summary>
        /// the email of applicant
        /// </summary>
        /// <example>alireza.yadegary@gmail.com</example>
        public string EMailAddress { get; set; }

        /// <summary>
        /// the age of applicant
        /// </summary>
        /// <example>34</example>
        public int Age { get; set; }

        /// <summary>
        /// the hire status of applicant
        /// </summary>
        /// <example>true</example>
        public bool? Hired { get; set; }
    }
}
