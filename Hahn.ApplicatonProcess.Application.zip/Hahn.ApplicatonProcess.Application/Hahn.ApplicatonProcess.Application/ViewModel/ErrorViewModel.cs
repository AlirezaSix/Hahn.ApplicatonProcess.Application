﻿using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using Newtonsoft.Json;

namespace Hahn.ApplicatonProcess.December2020.Web.ViewModel
{
    public class ErrorViewModel
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public ErrorType ErrorType { get; set; }
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
