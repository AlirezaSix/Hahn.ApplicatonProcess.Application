﻿using Hahn.ApplicatonProcess.December2020.Domain.Enumeration;
using Hahn.ApplicatonProcess.December2020.Domain.Exceptions;
using Hahn.ApplicatonProcess.December2020.Web.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Middleware
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate next;
        private readonly Microsoft.Extensions.Logging.ILogger logger;
        public ExceptionMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
        {
            this.next = next;
            logger = loggerFactory
                      .CreateLogger<ExceptionMiddleware>();
        }
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await next(httpContext);
            }
            catch (Exception ex)
            {
                logger.LogError($"there is an error in request {httpContext.Request.Path} with param {JsonConvert.SerializeObject(httpContext.Request.Query)} of type {ex.GetType()} with message: {ex}");
                await HandleExceptionAsync(httpContext, ex);
            }
        }
        private Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            var result = new ErrorViewModel();

            switch (exception)
            {
                case InvalidPropertyValueException ex:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    result.ErrorType = ex.ErrorType;
                    result.Message = ex.Message;
                    break;
                case NotFoundException ex:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    result.ErrorType = ex.ErrorType;
                    result.Message = ex.Message;
                    break;
                case Domain.Exceptions.NullReferenceException ex:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    result.ErrorType = ex.ErrorType;
                    result.Message = ex.Message;
                    break;
                case RepositoryException ex:
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    result.ErrorType = ex.ErrorType;
                    result.Message = ex.Message;
                    break;
                default:
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    result.ErrorType = ErrorType.UnHandledException;
                    result.Message = "an unhandled exception has been occured";
                    break;
            }

            result.StatusCode = context.Response.StatusCode;

            return context.Response.WriteAsync(result.ToString());
        }
    }
}
