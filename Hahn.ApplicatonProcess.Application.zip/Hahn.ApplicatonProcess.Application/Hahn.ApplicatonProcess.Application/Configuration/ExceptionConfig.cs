﻿using Hahn.ApplicatonProcess.December2020.Web.Middleware;
using Microsoft.AspNetCore.Builder;

namespace Hahn.ApplicatonProcess.December2020.Web.Configuration
{
    public static class ExceptionConfig
    {
        public static void ConfigureCustomExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<ExceptionMiddleware>();
        }
    }
}
