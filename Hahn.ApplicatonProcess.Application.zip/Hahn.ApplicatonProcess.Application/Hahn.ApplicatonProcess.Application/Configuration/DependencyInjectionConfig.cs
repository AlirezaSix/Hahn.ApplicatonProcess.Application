﻿using FluentValidation;
using FluentValidation.AspNetCore;
using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.DI;
using Hahn.ApplicatonProcess.December2020.Web.Validator;
using Hahn.ApplicatonProcess.December2020.Web.ViewModel.V1.Applicant;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Hahn.ApplicatonProcess.December2020.Web.Configuration
{
    public static class DependencyInjectionConfig
    {
        internal static void RegisterDependencyInjection(this IServiceCollection services)
        {
            List<IDependencyRegistrar> dependencyRegistrars = new List<IDependencyRegistrar>();
            dependencyRegistrars.Add(new  Data.Service.DependencyRegistrar());
            dependencyRegistrars.Add(new Domain.Service.Implementation.DependencyRegistrar());

            foreach (var item in dependencyRegistrars.OrderBy(x => x.Order).ToList())
            {
                item.Register(services);
            }

            services.AddControllers().AddFluentValidation(fv => { });
            services.AddTransient<IValidator<InsertApplicantRequestViewModel>, ApplicantValidator>();
        }

        private static List<Type> GetAllClasses<TInterface>()
        {
            return Directory.GetFiles(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "*.dll")
                .Where(x => Path.GetFileName(x.ToLower()).Contains("hahn"))
                .Select(dll => Assembly.LoadFile(dll))
                .SelectMany(s => s.GetTypes())
                .Where(p => typeof(TInterface).IsAssignableFrom(p))
                .Select(x => x).ToList();
        }
    }
}
