﻿using Hahn.ApplicatonProcess.December2020.Web.Middleware;
using Microsoft.AspNetCore.Builder;

namespace Hahn.ApplicatonProcess.December2020.Web.Configuration
{
    public static class RequestResponseLoggingConfig
    {
        public static IApplicationBuilder UseRequestResponseLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestResponseLoggingMiddleware>();
        }
    }
}
