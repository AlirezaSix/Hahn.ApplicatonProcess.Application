﻿using Hahn.ApplicatonProcess.December2020.Domain.Dto.Applicant;
using Hahn.ApplicatonProcess.December2020.Web.ViewModel.V1.Applicant;
using System.Collections.Generic;
using System.Linq;

namespace Hahn.ApplicatonProcess.December2020.Web.Mapping
{
    internal static class ApplicantMapper
    {
        internal static ApplicantInsertRequestDto ToDto(this InsertApplicantRequestViewModel source)
        {
            if (source == null)
            {
                return null;
            }

            return new ApplicantInsertRequestDto()
            {
                Address = source.Address,
                Age = source.Age,
                CountryOfOrigin = source.CountryOfOrigin,
                EMailAddress = source.EMailAddress,
                FamilyName = source.FamilyName,
                Hired = source.Hired,
                Name = source.Name
            };
        }

        internal static ApplicantUpdateRequestDto ToDto(this UpdateApplicantRequestViewModel source,int id)
        {
            if (source == null)
            {
                return null;
            }

            return new ApplicantUpdateRequestDto()
            {
                Address = source.Address,
                Age = source.Age,
                CountryOfOrigin = source.CountryOfOrigin,
                EMailAddress = source.EMailAddress,
                FamilyName = source.FamilyName,
                Hired = source.Hired,
                Name = source.Name,
                ID = id
            };
        }

        internal static ApplicantDeleteRequestDto ToDto(this int source)
        {
            return new ApplicantDeleteRequestDto()
            {
                ID = source
            };
        }

        internal static IEnumerable<ApplicantViewModel> ToViewModel(this IEnumerable<ApplicantDto> model)
        {
            if (model?.Any() ?? false)
            {
                return (from x in model select x.ToViewModel());
            }

            return new List<ApplicantViewModel>();
        }
        internal static ApplicantViewModel ToViewModel(this ApplicantDto source)
        {
            if (source == null)
            {
                return new ApplicantViewModel();
            }

            return new ApplicantViewModel()
            {
                Address = source.Address,
                Age = source.Age,
                CountryOfOrigin = source.CountryOfOrigin,
                EMailAddress = source.EMailAddress,
                FamilyName = source.FamilyName,
                Hired = source.Hired,
                Name = source.Name,
                ID = source.ID
            };
        }
    }
}
