﻿using Hahn.ApplicatonProcess.December2020.Domain;
using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.Security;
using Hahn.ApplicatonProcess.December2020.Domain.Service;
using Hahn.ApplicatonProcess.December2020.Web.Mapping;
using Hahn.ApplicatonProcess.December2020.Web.ViewModel.V1.Applicant;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Mime;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers.V1
{
    /// <summary>
    /// this controller is responsible for doing get/remove/add/update oprations on an applicant
    /// </summary>
    [Route("api/V1/[controller]")]
    public class ApplicantController : BaseApplicationProcessApiController
    {
        private readonly IAppliacantService appliacantService;
        private readonly ICountryValidatorService countryValidatorService;
        public ApplicantController(
            IAppliacantService appliacantService,
            ICountryValidatorService countryValidatorService)
        {
            this.appliacantService = appliacantService;
            this.countryValidatorService = countryValidatorService;
        }


        /// <summary>
        /// Retrieves all Applicants
        /// </summary>
        /// <response code="200">applicants found</response>
        /// <response code="204">applicant not found</response>
        /// <response code="500">Oops! Can't get applicants right now</response>
        [HttpGet("getall")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(ApplicantViewModel[]),StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetAll()
        {
            var result = await appliacantService.GetAsync();
            return Ok(result?.ToViewModel());
        }


        /// <summary>
        /// Retrieves a specific applicant by unique id. note that this is a encrypted id
        /// </summary>
        /// <remarks>this is an encrypted data so use this as this example :  "6ywsG0KSbZg="</remarks>
        /// <example>6ywsG0KSbZg=</example>
        /// <param name="id" example="6ywsG0KSbZg="></param>
        /// <response code="200">applicant found</response>
        /// <response code="204">applicant not found</response>
        /// <response code="400">request has missing/invalid values</response>
        /// <response code="500">Oops! Can't get applicant right now</response>
        [HttpGet("{id}")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(ApplicantViewModel),StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public async Task<IActionResult> GetById(int id)
        {
            if (!ModelState.IsValid)
            {
                BadRequest(ModelState);
            }

            var result = await appliacantService.GetByIdAsync(id);
            return Ok(result?.ToViewModel());
        }


        /// <summary>
        /// Creates an Applicant.
        /// </summary>
        /// <param name="insertApplicantRequestViewModel"></param>
        /// <response code="201">applicant created</response>
        /// <response code="400">request has missing/invalid values</response>
        /// <response code="500">Oops! Can't create applicant right now</response>
        [HttpPost]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(ApplicantViewModel), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Post([FromBody] InsertApplicantRequestViewModel insertApplicantRequestViewModel)
        {
            if (!ModelState.IsValid)
            {
                BadRequest(ModelState);
            }

            var result = (await appliacantService.InsertAsync(insertApplicantRequestViewModel.ToDto())).ToViewModel();

            return CreatedAtAction(nameof(GetById),new { id = Authenticating.DesEncryptId(ConstantEntityGuid.ApplicantId, result.ID) }, result);
        }


        /// <summary>
        /// Update An Applicant.
        /// </summary>
        /// <remarks>this is an encrypted data so use this as this example :  "6ywsG0KSbZg="</remarks>
        /// <param name="id" example="6ywsG0KSbZg="></param>     
        /// <param name="updateApplicantRequestViewModel"></param>     
        /// <response code="200">applicant updated</response>
        /// <response code="400">request has missing/invalid values</response>
        /// <response code="500">Oops! Can't update applicant right now</response>
        [HttpPut("{id}")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(ApplicantViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Put(int id, [FromBody] UpdateApplicantRequestViewModel updateApplicantRequestViewModel)
        {
            if (!ModelState.IsValid)
            {
                BadRequest(ModelState);
            }

            var result = await appliacantService.UpdateAsync(updateApplicantRequestViewModel.ToDto(id));
            return Ok(result.ToViewModel());

        }


        /// <summary>
        /// Delete Applicant By ID
        /// </summary>
        /// <remarks>this is an encrypted data so use this as this example :  "6ywsG0KSbZg="</remarks>
        /// <param name="id" example="6ywsG0KSbZg="></param>     
        /// /// <returns>Requeted Applicant</returns>
        /// <response code="200">applicant deleted</response>
        /// <response code="400">request has missing/invalid values</response>
        /// <response code="500">Oops! Can't delete applicant right now</response>
        [HttpDelete("{id}")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Delete(int id)
        {
            if (!ModelState.IsValid)
            {
                BadRequest(ModelState);
            }

            var result = await appliacantService.DeleteAsync(id.ToDto());
            return Ok(result);
        }

        /// <summary>
        /// check existance of country By name.
        /// </summary>
        /// <param name="name" example="Aruba"></param>     
        /// <response code="200">country found</response>
        /// <response code="400">request has missing/invalid values</response>
        /// <response code="500">Oops! Can't check country right now</response>
        [HttpGet("validateCountry")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> ValidateCountry(string name)
        {
            if (!ModelState.IsValid)
            {
                BadRequest(ModelState);
            }

            var result = countryValidatorService.Exist(name);

            if(!result)
            {
                BadRequest();
            }

            return Ok(result);
        }
    }
}
