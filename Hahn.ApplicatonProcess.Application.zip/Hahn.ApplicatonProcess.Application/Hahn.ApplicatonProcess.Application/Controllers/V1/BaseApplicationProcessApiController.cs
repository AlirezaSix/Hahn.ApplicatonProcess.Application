﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers.V1
{
    [ApiController]
    public class BaseApplicationProcessApiController : ControllerBase
    {
    }
}
