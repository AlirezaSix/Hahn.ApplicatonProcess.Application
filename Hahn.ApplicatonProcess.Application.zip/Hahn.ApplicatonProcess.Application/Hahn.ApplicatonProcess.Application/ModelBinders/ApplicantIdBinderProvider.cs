﻿using Hahn.ApplicatonProcess.December2020.Web.ViewModel.V1.Applicant;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ModelBinding.Binders;
using System;

namespace Hahn.ApplicatonProcess.December2020.Web.ModelBinders
{
    public class ApplicantBinderProvider : IModelBinderProvider
    {
        public IModelBinder GetBinder(ModelBinderProviderContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            if (context.Metadata.ModelType == typeof(int))
            {
                return new BinderTypeModelBinder(typeof(ApplicantIdModelBinder));
            }


            return null;
        }
    }
}
