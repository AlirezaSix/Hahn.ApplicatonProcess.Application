﻿using Hahn.ApplicatonProcess.December2020.Domain;
using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.Security;
using Hahn.ApplicatonProcess.December2020.Domain.Mapping;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.ModelBinders
{
    public class ApplicantIdModelBinder : IModelBinder
    {
        private Guid EntityGuid => ConstantEntityGuid.ApplicantId;

        public Task BindModelAsync(ModelBindingContext bindingContext)
        {
            if (bindingContext == null)
            {
                throw new ArgumentNullException(nameof(bindingContext));
            }

            var modelName = bindingContext.ModelName;

            var valueProviderResult = bindingContext.ValueProvider.GetValue(modelName);

            if (valueProviderResult == ValueProviderResult.None)
            {
                return Task.CompletedTask;
            }

            bindingContext.ModelState.SetModelValue(modelName, valueProviderResult);

            var value = valueProviderResult.FirstValue;

            if (string.IsNullOrEmpty(value))
            {
                return Task.CompletedTask;
            }

            if (int.TryParse(value, out var id))
            {
                bindingContext.ModelState.TryAddModelError(modelName, "Id must be encrypted.");
                return Task.CompletedTask;
            }

            bindingContext.Result = ModelBindingResult.Success(Authenticating.DesDecryptId(EntityGuid, value));
            return Task.CompletedTask;
        }
    }
}
