﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Threading.Tasks;
using System.Web.Http.Controllers;

namespace Hahn.ApplicatonProcess.December2020.Web.ModelBinders
{
    public abstract class ApplicationProcessModelBinder<T> : IModelBinder
    {
        public async Task BindModelAsync(ModelBindingContext bindingContext)
        {
            if (bindingContext == null || bindingContext.ModelType != typeof(T))
            {
                return;
            }

            BindModelWise(bindingContext);
        }

        public abstract bool BindModelWise( ModelBindingContext bindingContext);
    }
}
