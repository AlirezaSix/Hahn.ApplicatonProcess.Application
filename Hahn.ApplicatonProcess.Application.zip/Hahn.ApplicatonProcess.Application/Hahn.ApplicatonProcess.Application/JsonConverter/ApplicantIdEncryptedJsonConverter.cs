﻿using Hahn.ApplicatonProcess.December2020.Domain;
using Hahn.ApplicatonProcess.December2020.Domain.Infrastructure.JsonConverters;
using System;

namespace Hahn.ApplicatonProcess.December2020.Web.JsonConverter
{
    public class ApplicantIdEncryptedJsonConverter : IntEncryptedJsonConverter
    {
        protected override Guid EntityGuid => ConstantEntityGuid.ApplicantId;
    }
}
