var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { autoinject } from 'aurelia-dependency-injection';
import { routes } from './routes';
import '../node_modules/@fortawesome/fontawesome-free/css/all.min.css';
require('bootstrap/dist/css/bootstrap.min.css');
require('bootstrap');
var formLine = require("./asset/image/form-line.png");
var hostGroup = require("./asset/image/host-group.png");
var App = (function () {
    function App() {
    }
    App.prototype.configureRouter = function (config, router) {
        this.router = router;
        config.map(routes);
    };
    App.prototype.getValue = function (name) {
        if (name === 'list')
            return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEkAAABdCAYAAADpNEtRAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAASaADAAQAAAABAAAAXQAAAACcX7dkAAAC50lEQVR4Ae2csUocURSGjQQCEcQqARsXfIBAUhvTpLNIJXYhb5AHsDBPYhchlUWshJCQNsXWqaJdrJQQSGf+owxzWPYMP3fnrHfc/8Jxztz555wz371z111nXVqqo31DGdcV2R/UcghbgVXTaoPUDNhXI7RcCaZa6pjEsY2OzVqLmyz2LvfXBYnAL0gEJElaAt/hNgu2325pJrWQQk+QQjTtAUFqWYSeIIVo2gOC1LIIvT4hfUYW/6pQk/8XtR3BVkMSHQf6hNSR5s4PPUYFe7AvJZUsCqSGzQs4z5sddrtokIzLOgun0S0ipOba6a0gEaj6hLSDfA8qshPi+ilJn5CohEMUCRIxaoIkSAQBQvLQadbgP3P7NbtXKG48rwINksE5hL2ZV9Ke8lwizjvYcU/xwjC2Jh3AhgbILmgNZoM7gqU2g/Q2NUNucAP1KjfF7R8nLdGQ2yi7eP0KQBAWpBkhfcD5Nb0XIy4nR6KZRHAVJEEiCBASzSQCkn/vRshvJE/x8xErLtCdF5yTekoJpE+o6GViVRbbnvCopul2I4ZCkASJIEBINJMISCUL92/EPSNil0r+lZ6YdV4JpN2sYmqNq9uNGBlBEiSCACHRTBIkggAh0UwSJIIAIdFMEiSCACHRTBIkggAh0UwSJIIAIdFMEiSCACHRTBIkggAhKflkkgg7SMlWVLVut4iM6xckByNyBSki4/oFycGIXEGKyLh+QXIwIleQIjKuX5AcjMgVpIiM6xckByNyBSki4/oFycGIXEGKyLj+rE8BXiPHE5encU/hXDQ7yduPiP9jSo6fU/o6u7Ig7SPrtMeYrW+ekDovnj2o240gJUiCRBAgJJpJgkQQICRZr272GPO0bzKdEzVVJ8mCZA/E35umNYkYSkESJIIAIelakzZw/jYRYyEk17jKIdtB9ihpTSIICxIJKfMLfkQJM0vGM0cgAryHZqhr0i/UPrf//2SgLOGQYB2j3hEsvf0HgTIjw4SgUgAAAAAASUVORK5CYII=';
        else if (name === 'add' || name === 'edit')
            return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAYKADAAQAAAABAAAAYAAAAACK+310AAAInklEQVR4Ae1cSYhdRRRtTRYBxQzOEDEhjgvBjRs1imtB3TgslHzcCS5UXBiJpBVRcUpAcCNCC7rQKEQFJ5xFUEEiQWPUaLezGDVGBBeO53S6Ou/Xr1PTm/77vgvXenXnOve9+q/r/zg1NTW1ArwFPAv+t+d5DIjFZnAjtBVZeuDdGBCbWukQRN8H5lPQ0ygCcxCtHRVXJ2EDePf3pBEgRrXRobVF7gNHIdA3IAqm+oyWekLX+uh58ralamUr7p+Attq9kLdvQN+AlhFoOX3/BPQNaBmBltPnPAFdPDuaBc6bW8Zapufrl4uVQ5fPjnxnOy4MKKuVfEcR6u+ALp8dzQHNtQJRBbbCQYRJE+c0QBWalrk9awWoWpeyr2QFOZ8BlSTugxxAwHcUkYrRG6kONdufX3P8SsJXuQXV+qhmrDZ1S0m1zyhp1KXfgkYxaVTSN6BRuEeT9Q0YxaRRSd+ARuEeTdY3YBSTRiVVvoaqt4hGF9S1ZP0T0HLH+gZ0sAH7W665TPovyzjX4ZvzBPiOdOuoscqYM1UGqyoWPzxd7IvPJswJP1estmWsdRrsI1Wjz6e0LucsqHTSMQ3ABrio1jOunC3IVeSkyh6pe2FV/h1Qd61Nx78VCacDSa+Cft2CzQ6MTwfsnepW9j5nJe0KizgMAqWcCP3n4KIPr98GLwcnkR3EzJOCTICxWfcgsJbV0M+Cjb098kk4IhBjSG0HMPMho//BhOseBNYZAt9gxyasDMSaV+e+BV0C7w3gFTFJxsDmV9TAD9TtnloG0M149AT/LfAaj01R9REm68H7ikLXtemaPbpsKbsObNt2Zc7acyj2zrdx+BDJgk+C7WTmqtBZKIxN10ZuDal0HBzKrJlNOMqXVIGofJR9V+RqXS45wf8M7FvbJujJPpvd0MsmKEf4OEnZd0XuXJRDGAP+jQU/XvswkE1QToXYQ5fKvivyocWISSr4JkxME441xmZUwBm9Paba2/5NzXPrzAXfrCvUBP4BN9SE1EJT7U1hTY+uOgeBIo6HPrTn3xWIQfXNYFd+I9sDPXPNkxHao9Hbo21n5rZd23NTlxkHgYJ4538CNvZqJHirA7Go3ghWMSh/lkYkZXRAO/rfVPvRCM1IinUOAikJ/qfgoo/veugO9sQOPQmX01clUnFT7VWcuuWmzkEgUSr4Ji63qsVtxJPD14T501MT0B5VTNvOzJV9W3LWNQgkj9l2eOT8ONisszjyqWGMEL0Mg6KfueaW51TQQJFxHvdxoBawICdwu8G+dVxZiKGaQBB9Tbjdk+NVxlcFUOciZT9O8mlX4QVZDPi8821STWAjXU24A3IfLgMmUAbUuUjZj4t8xlV0QXY0rj8G++q9umBvXz4hfNkExjZ0Hy58OXYaQ2Vk9PbIo13l07Z8xi7WmofA/wf2PvBNOH54utbKxjLHA0JvfGahX3yVNUJ7hI2TpiG1bcdhPuOs9qCQ391+C/bVes1B8+DVkyIWz/99OfgKuwg+syhj6hRthWIOrHybls+gFh/xrvwa7KsrBXzm4g8a1JOg8szCZwh8BlLG1E0ChbYdrj8VfINLShOc4DPQJDeA4O/yrJFrvx5chpbB+SewwpHyL8Ajdz5k86Qcjb6rY8ydn/sVpcEk5gmYhbEEn4EmsQEx4N9kUMwcl8Av9BkQBJ+5J60BTYG/zYMdMY0Cf9IaEAP+NBddgnjnVwY+60h9AvhbolvAP3h8Vcwycv5Z76MY8O/0BYjQxYDP113vnm/nUaDYdmZ+Py6UT13yEPirUFPoeGGLWUDmyF+Sh+58gr8mNb4CTcXZC4XyqUN+jypkQU7wea7iy10F+I8GcmSBzzWowqlzkbKvQz7x4BNgBZwLfJ+9ipMrrwL8B9UiIuXcdmq7800NCiCjt0dlX6V8HMDny0bt4BNcBZwNvJmn2hu/qsaYPf/hkskIPmOotVKevefbtakktp2Zp9obvyrGWPAJYC41Cj6LTAU01T4XCNsvBnxuGZ0Cn4tMBTTV3gYyZx4LPj80y1Bo2/kewdeUSeDyTQU01d6VM0XWFPh8Y1Jro5zgn5RSeKytSqr8U+1VnBh5DPjbEKjsnd8a+AQhFVBlnyp/JdCBWPCXBOKE1K2Cz+IUcKpwZZ8q9x2MLUfynZ7amItn8Z0HH2tIbgB/upEKtsv+QiZ3EMF/H+zyMTKCv9ThmyLi+ZCJ5xpr2/PtIl3JKVO0BwrlEyv/GzEOFwkeC8TfLvxSxPcGcvCo/ZSUgGVsFWgq5mVQEEDlFyPfoYJD7vuC+3noJ+bOJwY5i+FP83iHXAs+BpxDzwindZAfKXQvQH4x+C+hjxHzc8f3RTzXtR7Mp7wxUndsYwUUEm3AtaueXwo2uZehH8ruReDGtp3iIlwLpqwNeghJXfWoJya2Rt75rrhG9iP0p8UGq9rOFGGPVeeJiae+Viz+e9yYOEWbaUzstRXnrYLPQovFFK+pa5K49xfzF6/PyiyEv/0pxrGvWwef67KLMvPMNWe7XSRq+QPynKOGToBPtAzg9khdk3Q3ktk1cP5iRhGdAd/3GvpaxsJjXC4QRucK+ZtCrsR8zfQdc/Bt5zzwbhWgabnrrqtL9oFY3DLI/wS78vK9PJYIviuGkY3Fnm8vxhTXxDhjJ1+YE2RXfu7/MbQSRpvArhhGRvBPjwnWpA23oP1gHoA1Qa+LJOouf1fYnwr5OeCzF5jv8L6vIvmH3FhtO6hnkaZxZe6SusczF7MOXzwnargNcm5PBG8jmP9/Bd9Zkav+n+FzBnisaSuqmwO7FlClTIHwm8j9lZDH1sRmjT34CpSm5KtKgqya0YMf2cHDamhAD34k+MbspQqa8A1ibAPfAF4L7ikBgZNh+ztYbScuOd+Q+G8VLgWfAO6pJAJ8R38H7AL7O8ifAvNUlK+fE0O+d+e2FnkFEvO9nrQL/B54DjyR9B9s5hQcJaHRgwAAAABJRU5ErkJggg==';
        return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAYKADAAQAAAABAAAAYAAAAACK+310AAAInklEQVR4Ae1cSYhdRRRtTRYBxQzOEDEhjgvBjRs1imtB3TgslHzcCS5UXBiJpBVRcUpAcCNCC7rQKEQFJ5xFUEEiQWPUaLezGDVGBBeO53S6Ou/Xr1PTm/77vgvXenXnOve9+q/r/zg1NTW1ArwFPAv+t+d5DIjFZnAjtBVZeuDdGBCbWukQRN8H5lPQ0ygCcxCtHRVXJ2EDePf3pBEgRrXRobVF7gNHIdA3IAqm+oyWekLX+uh58ralamUr7p+Attq9kLdvQN+AlhFoOX3/BPQNaBmBltPnPAFdPDuaBc6bW8Zapufrl4uVQ5fPjnxnOy4MKKuVfEcR6u+ALp8dzQHNtQJRBbbCQYRJE+c0QBWalrk9awWoWpeyr2QFOZ8BlSTugxxAwHcUkYrRG6kONdufX3P8SsJXuQXV+qhmrDZ1S0m1zyhp1KXfgkYxaVTSN6BRuEeT9Q0YxaRRSd+ARuEeTdY3YBSTRiVVvoaqt4hGF9S1ZP0T0HLH+gZ0sAH7W665TPovyzjX4ZvzBPiOdOuoscqYM1UGqyoWPzxd7IvPJswJP1estmWsdRrsI1Wjz6e0LucsqHTSMQ3ABrio1jOunC3IVeSkyh6pe2FV/h1Qd61Nx78VCacDSa+Cft2CzQ6MTwfsnepW9j5nJe0KizgMAqWcCP3n4KIPr98GLwcnkR3EzJOCTICxWfcgsJbV0M+Cjb098kk4IhBjSG0HMPMho//BhOseBNYZAt9gxyasDMSaV+e+BV0C7w3gFTFJxsDmV9TAD9TtnloG0M149AT/LfAaj01R9REm68H7ikLXtemaPbpsKbsObNt2Zc7acyj2zrdx+BDJgk+C7WTmqtBZKIxN10ZuDal0HBzKrJlNOMqXVIGofJR9V+RqXS45wf8M7FvbJujJPpvd0MsmKEf4OEnZd0XuXJRDGAP+jQU/XvswkE1QToXYQ5fKvivyocWISSr4JkxME441xmZUwBm9Paba2/5NzXPrzAXfrCvUBP4BN9SE1EJT7U1hTY+uOgeBIo6HPrTn3xWIQfXNYFd+I9sDPXPNkxHao9Hbo21n5rZd23NTlxkHgYJ4538CNvZqJHirA7Go3ghWMSh/lkYkZXRAO/rfVPvRCM1IinUOAikJ/qfgoo/veugO9sQOPQmX01clUnFT7VWcuuWmzkEgUSr4Ji63qsVtxJPD14T501MT0B5VTNvOzJV9W3LWNQgkj9l2eOT8ONisszjyqWGMEL0Mg6KfueaW51TQQJFxHvdxoBawICdwu8G+dVxZiKGaQBB9Tbjdk+NVxlcFUOciZT9O8mlX4QVZDPi8821STWAjXU24A3IfLgMmUAbUuUjZj4t8xlV0QXY0rj8G++q9umBvXz4hfNkExjZ0Hy58OXYaQ2Vk9PbIo13l07Z8xi7WmofA/wf2PvBNOH54utbKxjLHA0JvfGahX3yVNUJ7hI2TpiG1bcdhPuOs9qCQ391+C/bVes1B8+DVkyIWz/99OfgKuwg+syhj6hRthWIOrHybls+gFh/xrvwa7KsrBXzm4g8a1JOg8szCZwh8BlLG1E0ChbYdrj8VfINLShOc4DPQJDeA4O/yrJFrvx5chpbB+SewwpHyL8Ajdz5k86Qcjb6rY8ydn/sVpcEk5gmYhbEEn4EmsQEx4N9kUMwcl8Av9BkQBJ+5J60BTYG/zYMdMY0Cf9IaEAP+NBddgnjnVwY+60h9AvhbolvAP3h8Vcwycv5Z76MY8O/0BYjQxYDP113vnm/nUaDYdmZ+Py6UT13yEPirUFPoeGGLWUDmyF+Sh+58gr8mNb4CTcXZC4XyqUN+jypkQU7wea7iy10F+I8GcmSBzzWowqlzkbKvQz7x4BNgBZwLfJ+9ipMrrwL8B9UiIuXcdmq7800NCiCjt0dlX6V8HMDny0bt4BNcBZwNvJmn2hu/qsaYPf/hkskIPmOotVKevefbtakktp2Zp9obvyrGWPAJYC41Cj6LTAU01T4XCNsvBnxuGZ0Cn4tMBTTV3gYyZx4LPj80y1Bo2/kewdeUSeDyTQU01d6VM0XWFPh8Y1Jro5zgn5RSeKytSqr8U+1VnBh5DPjbEKjsnd8a+AQhFVBlnyp/JdCBWPCXBOKE1K2Cz+IUcKpwZZ8q9x2MLUfynZ7amItn8Z0HH2tIbgB/upEKtsv+QiZ3EMF/H+zyMTKCv9ThmyLi+ZCJ5xpr2/PtIl3JKVO0BwrlEyv/GzEOFwkeC8TfLvxSxPcGcvCo/ZSUgGVsFWgq5mVQEEDlFyPfoYJD7vuC+3noJ+bOJwY5i+FP83iHXAs+BpxDzwindZAfKXQvQH4x+C+hjxHzc8f3RTzXtR7Mp7wxUndsYwUUEm3AtaueXwo2uZehH8ruReDGtp3iIlwLpqwNeghJXfWoJya2Rt75rrhG9iP0p8UGq9rOFGGPVeeJiae+Viz+e9yYOEWbaUzstRXnrYLPQovFFK+pa5K49xfzF6/PyiyEv/0pxrGvWwef67KLMvPMNWe7XSRq+QPynKOGToBPtAzg9khdk3Q3ktk1cP5iRhGdAd/3GvpaxsJjXC4QRucK+ZtCrsR8zfQdc/Bt5zzwbhWgabnrrqtL9oFY3DLI/wS78vK9PJYIviuGkY3Fnm8vxhTXxDhjJ1+YE2RXfu7/MbQSRpvArhhGRvBPjwnWpA23oP1gHoA1Qa+LJOouf1fYnwr5OeCzF5jv8L6vIvmH3FhtO6hnkaZxZe6SusczF7MOXzwnargNcm5PBG8jmP9/Bd9Zkav+n+FzBnisaSuqmwO7FlClTIHwm8j9lZDH1sRmjT34CpSm5KtKgqya0YMf2cHDamhAD34k+MbspQqa8A1ibAPfAF4L7ikBgZNh+ztYbScuOd+Q+G8VLgWfAO6pJAJ8R38H7AL7O8ifAvNUlK+fE0O+d+e2FnkFEvO9nrQL/B54DjyR9B9s5hQcJaHRgwAAAABJRU5ErkJggg==';
    };
    App = __decorate([
        autoinject
    ], App);
    return App;
}());
export { App };
var CategoriesValueConverter = (function () {
    function CategoriesValueConverter() {
    }
    CategoriesValueConverter.prototype.toView = function (navModels) {
        var categories = new Map();
        for (var _i = 0, navModels_1 = navModels; _i < navModels_1.length; _i++) {
            var model = navModels_1[_i];
            var routes_1 = categories.get(model.settings.category);
            if (!routes_1) {
                categories.set(model.settings.category, routes_1 = []);
            }
            routes_1.push(model);
        }
        return categories;
    };
    return CategoriesValueConverter;
}());
export { CategoriesValueConverter };
//# sourceMappingURL=app.js.map