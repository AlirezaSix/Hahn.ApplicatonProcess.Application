import { autoinject, bindable } from 'aurelia-framework';
import { Router } from 'aurelia-router';
import { DialogService } from "aurelia-dialog";
import { I18N } from 'aurelia-i18n';

import { applicantService } from '../../services/index';
import {  Applicant } from '../../models/index';
import { ConfirmDialog } from './confirmDialog';

@autoinject
export class List {
  public applicants: Applicant[];

  @bindable
  action = () => { };

  @bindable
  msg = "";
  title = '';

  constructor(private router: Router, public dlg: DialogService, public i18n: I18N) {
    this.initial();
    this.msg = i18n.tr('are-you-sure-delete-data');
    this.title = i18n.tr('delete-data');
  }

  async initial() {
    this.applicants = await applicantService.getAllApplicants();

  }

  public edit(applicant: Applicant) {
    this.router.navigateToRoute('edit', { id: applicant.id });
  }

  public async delete(applicant: Applicant) {
    const result = await this.dlg.open({ viewModel: ConfirmDialog, model: { message: this.msg, title: this.title } }).whenClosed();
    if (result.wasCancelled) return;

    const response = await applicantService.deleteApplicant(applicant.id);
    if (response) this.applicants.splice(this.applicants.indexOf(applicant), 1);
  }

  public add() {
    this.router.navigate('/add');
  }
}
