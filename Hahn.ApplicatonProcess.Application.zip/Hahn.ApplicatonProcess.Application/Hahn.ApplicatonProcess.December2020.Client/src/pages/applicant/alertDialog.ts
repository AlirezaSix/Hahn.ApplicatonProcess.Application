import { autoinject } from "aurelia-framework";
import { DialogController } from 'aurelia-dialog';

@autoinject
export class AlertDialog {

  constructor(public controller: DialogController) {
    this.controller.settings.position = (modalContainer: Element, modalOverlay: Element) => {
      let container = modalContainer;
      let overlay = modalOverlay;
    }
  }
  title = "";
  messages = [];
  activate({title, messages}) {
    this.title = title;
    this.messages = messages ?? [];
  }
}
