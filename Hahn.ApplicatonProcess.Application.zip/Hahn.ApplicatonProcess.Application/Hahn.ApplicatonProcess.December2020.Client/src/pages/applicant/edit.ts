import { autoinject, bindable } from 'aurelia-framework';
import { Router } from 'aurelia-router';
import {
  Validator,
  ValidationController,
  ValidationControllerFactory,
  ValidationRules,
  validateTrigger,
} from 'aurelia-validation';
import { DialogService } from "aurelia-dialog";
import { I18N } from 'aurelia-i18n';

import { applicantService } from '../../services/index';
import {  Applicant } from '../../models/index';
import { ConfirmDialog } from './confirmDialog';
import { AlertDialog } from './alertDialog';


const emptyApplicant = { id: 0, name: '', familyName: '', address: '', countryOfOrigin: '', eMailAddress: '', age: 0, hired: null };


@autoinject
export class Add {
  public applicant: Applicant;
  public canSave: Boolean;
  private controller: ValidationController;

  public loading: boolean = false;
  public errors: string[] = [];
  public canReset: boolean;

  @bindable
  action = () => { };

  @bindable
  msg = '';
  title = '';
  AlertTitle = '';

  nameError = "";
  familyNameError = "";
  addressError = "";
  countryError = "";
  ageError = "";
  emailError = "";

  constructor(private router: Router, private validator: Validator, controllerFactory: ValidationControllerFactory, public dlg: DialogService, public i18n: I18N) {
    this.controller = controllerFactory.createForCurrentScope(validator);
    this.controller.validateTrigger = validateTrigger.changeOrBlur;
    this.controller.subscribe(event => this.validateWhole());

    this.msg = i18n.tr('are-you-sure-reset-data');
    this.title = i18n.tr('reset-data');
    this.AlertTitle = i18n.tr('save-error');

    this.nameError = i18n.tr('name-5-char-range-error');
    this.familyNameError = i18n.tr('family-name-5-char-range-error');
    this.addressError = i18n.tr('address-10-char-range-error');
    this.emailError = i18n.tr('invalid-email-format');
    this.ageError = i18n.tr('agerage-20-60-error');
    this.countryError = i18n.tr('country-not-found');
  }

  private validateWhole() {
    this.validator.validateObject(this.applicant)
      .then(results => {
        this.canReset = this.dataExist();
        this.canSave = results.every(result => result.valid);
      });
  }

  private dataExist() {
    return this.applicant.name.length > 0 ||
      this.applicant.familyName.length > 0 ||
      this.applicant.eMailAddress.length > 0 ||
      this.applicant.countryOfOrigin.length > 0 ||
      this.applicant.address.length > 0 ||
      this.applicant.age != 0 ||
      this.applicant.hired == true
  }



  public async activate(params) {
    if (params.id) {
      this.applicant = await applicantService.getApplicant(params.id);
    } else {
      this.applicant = emptyApplicant;
    }

    this.setupValidation();
  }

  public setupValidation() {
    ValidationRules
      .ensure('name').required().minLength(5).withMessage(this.nameError)
      .ensure('familyName').required().minLength(5).withMessage(this.familyNameError)
      .ensure('eMailAddress').required().email().withMessage(this.emailError)
      .ensure('address').required().minLength(10).withMessage(this.addressError)
      .ensure('age').required().between(20, 60).withMessage(this.ageError)
      .ensure('countryOfOrigin').satisfies(applicantService.ValidateCountry).withMessage(this.countryError)
      .on(this.applicant);
  }

  public async save() {

    try {
      if (!this.canSave || this.loading) {
        return;
      }

      this.loading = true;
      if (this.applicant.id === 0 || this.applicant.id.toString().length === 0) {
        this.applicant = await applicantService.insertApplicant(this.applicant);
      }
      else {
        this.applicant = await applicantService.updateApplicant(this.applicant);
      }

      this.loading = false;
      this.resetForm();
      this.router.navigateToRoute('list');
    }
    catch (error) {
      this.loading = false;

      console.log(error)
    
      for (const  value of Object.values(error)) {
        if((value as string).length ===1){
          this.errors.push(error  );
          break;
        }
        this.errors.push(value as string);
      }

      await this.dlg.open({ viewModel: AlertDialog, model: { messages: this.errors, title: this.AlertTitle } }).whenClosed();

    }
  }

  public async reset() {
    const result = await this.dlg.open({ viewModel: ConfirmDialog, model: { message: this.msg, title: this.title } }).whenClosed();
    if (result.wasCancelled) return;

    this.resetForm();

  }

  public cancel() {
    this.resetForm();
    this.router.navigateToRoute('list');
  }

  private resetForm() {
    this.controller.reset();
    this.applicant = emptyApplicant;
    this.applicant.name = '';
    this.applicant.familyName = '';
    this.applicant.address = '';
    this.applicant.countryOfOrigin = '';
    this.applicant.eMailAddress = '';
    this.applicant.age = 0;
    this.applicant.hired = false;
  }
}

