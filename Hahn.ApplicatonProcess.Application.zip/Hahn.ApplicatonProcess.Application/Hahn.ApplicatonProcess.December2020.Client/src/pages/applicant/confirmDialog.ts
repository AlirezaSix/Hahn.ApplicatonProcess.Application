import { autoinject } from "aurelia-framework";
import { DialogController } from 'aurelia-dialog';

@autoinject
export class ConfirmDialog {

  constructor(public controller: DialogController) {
    this.controller.settings.position = (modalContainer: Element, modalOverlay: Element) => {
      let container = modalContainer;
      let overlay = modalOverlay;
    }
  }
  title = "";
  message = "";
  activate({title, message}) {
    this.title = title;
    this.message = message;
  }
}
