interface IPayloadInvoke<TDataInvoke> {
  entityName: string;
  actionName: string;
  data?: TDataInvoke;
  params?: IParams;
}

interface IParams {
  [key: string]: string | number | boolean;
}


interface Applicant{
  id:number;
  name:string;
  familyName:string;
  address:string;
  countryOfOrigin:string;
  eMailAddress:string;
  age:number;
  hired?:boolean;
}

interface ApplicantInsertRequest{
  name:string;
  familyName:string;
  address:string;
  countryOfOrigin:string;
  eMailAddress:string;
  age:number;
  hired?:boolean;
}

interface ApplicantUpdateRequest{
  id:number;
  name:string;
  familyName:string;
  address:string;
  countryOfOrigin:string;
  eMailAddress:string;
  age:number;
  hired?:boolean;
}

export {
  IPayloadInvoke,
  IParams,
  Applicant,
  ApplicantInsertRequest,
  ApplicantUpdateRequest
}
