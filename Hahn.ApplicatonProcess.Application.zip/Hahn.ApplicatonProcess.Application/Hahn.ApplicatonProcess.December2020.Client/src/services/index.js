import { applicantService } from './applicantService';
export { applicantService };
//# sourceMappingURL=index.js.map