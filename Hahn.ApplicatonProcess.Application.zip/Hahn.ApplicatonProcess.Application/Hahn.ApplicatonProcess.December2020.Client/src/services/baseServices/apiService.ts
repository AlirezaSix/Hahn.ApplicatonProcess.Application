import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';

import { baseUrl } from '../../utilities/index';
import {IPayloadInvoke} from '../../models/index';

const config: AxiosRequestConfig = {
  baseURL: baseUrl,
  headers:{
    'Content-Type':'application/json',
    'Accept':'application/json'
  }
};

const plusAxios: AxiosInstance = axios.create(config);

plusAxios.interceptors.response.use(
  response => {
    return response;
  },
);

const postAsync = async <TDataInvoke, THttpResponse>({
  entityName,
  actionName,
  data
}: IPayloadInvoke<TDataInvoke>): Promise<THttpResponse> => {
  try {
    const response = await plusAxios.post(
      `${entityName ? `/${entityName}` : ''}${actionName ? `/${actionName}` : ''}`,
      data,
    );
    return response.data;
  } catch (error) {
    return Promise.reject(error);
  }
};

const getAsync = async <THttpResponse>({
  entityName,
  actionName,
  params
}: IPayloadInvoke<null>): Promise<THttpResponse> => {
  try {
    const response = await plusAxios.get(
      `${entityName ? `/${entityName}` : ''}${actionName ? `/${actionName}` : ''}`,
      { params },
    );
    return response.data;
  } catch (error) {
    return Promise.reject(error);
  }
};

const putAsync = async <TDataInvoke,THttpResponse>({
  entityName,
  actionName,
  data
}: IPayloadInvoke<TDataInvoke>): Promise<THttpResponse> => {
  try {

    const response = await plusAxios.put(
      `${entityName ? `/${entityName}` : ''}${actionName ? `/${actionName}` : ''}`,
      JSON.stringify(data) ,
    );

    return response.data;
  } catch (error) {
    return Promise.reject(error);
  }
};

const deleteAsync = async <THttpResponse>({
  entityName,
  actionName,
  params
}: IPayloadInvoke<null>): Promise<THttpResponse> => {
  try {
    const response = await plusAxios.delete(
      `${entityName ? `/${entityName}` : ''}${actionName ? `/${actionName}` : ''}`,
      { params },
    );
    return response.data;
  } catch (error) {
    return Promise.reject(error);
  }
};

export const apiService = {
  getAsync,
  postAsync,
  putAsync,
  deleteAsync
};
