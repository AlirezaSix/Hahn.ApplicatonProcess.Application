import { apiService } from './baseServices/apiService';
import { Applicant, ApplicantInsertRequest, ApplicantUpdateRequest } from '../models/index';
import { validateEmail } from '../utilities/index';


const getApplicant = async (id: number): Promise<Applicant> => {
  try {

    if (id.toString().length == 0) {
      return Promise.reject("id must has value");
    }
    const result = await apiService.getAsync<Applicant>({ entityName: 'applicant', actionName: id.toString() });
    return result;
  }
  catch (error) {
    console.log(error);
    return Promise.reject(error.response.data.errors ?? error.response.data.Message)
  }
}

const getAllApplicants = async (): Promise<Applicant[]> => {
  try {
    const result = await apiService.getAsync<Applicant[]>({ entityName: 'applicant', actionName: 'getall' });
    return result;
  }
  catch (error) {
    console.log(error);
    return Promise.reject(error.response.data.errors ?? error.response.data.Message)
  }
}

const deleteApplicant = async (id: number): Promise<boolean> => {
  try {

    if (id.toString().length == 0) {
      return Promise.reject("id must has value");
    }

    const result = await apiService.deleteAsync<boolean>({ entityName: 'applicant', actionName: id.toString() });
    return result;
  }
  catch (error) {
    console.log(error);
    return Promise.reject(error.response.data.errors ?? error.response.data.Message)
  }
}

const validateApplicant = (model: Applicant): string => {
  if (model.id.toString().length == 0) {
    return "id must has value";
  }

  if (model.name.length < 5) {
    return "name must be at least 5 charecters";
  }
  else if (model.familyName.length < 5) {
    return "family must be at least 5 charecters";
  }

  else if (model.address.length < 10) {
    return "address must be at least 10 charecters";
  }

  else if (model.age < 20 || model.age > 60) {
    return "age must be between 20 and 60";
  }

  else if (!validateEmail(model.eMailAddress)) {
    return "email address not valid";
  }

  return "";
}

const ValidateCountry = async (countryName: string): Promise<boolean> => {
  try {
    const result = await apiService.getAsync<boolean>({ entityName: 'applicant', actionName: `validateCountry?name=${countryName}` });
    return Promise.resolve(result);
  }
  catch {
    return Promise.resolve(false);
  }
}

const updateApplicant = async (model: Applicant): Promise<Applicant> => {
  try {

    var validationResult = validateApplicant(model);

    if (validationResult.length > 0) {
      return Promise.reject(validationResult);
    }

    const checkCOuntry = await ValidateCountry(model.countryOfOrigin);

    if (!checkCOuntry) {
      return Promise.reject("country not found");
    }


    const param: ApplicantUpdateRequest = {
      address: model.address,
      age: model.age,
      countryOfOrigin: model.countryOfOrigin,
      eMailAddress: model.eMailAddress,
      familyName: model.familyName,
      name: model.name,
      hired: model.hired,
      id:model.id
    }

    const result = await apiService.putAsync<ApplicantUpdateRequest, Applicant>({ entityName: 'applicant', actionName: model.id.toString(), data: param });
    return result;
  }
  catch (error) {
    console.log(error);
    return Promise.reject(error.response.data.errors ?? error.response.data.Message)
  }
}

const insertApplicant = async (model: Applicant): Promise<Applicant> => {
  try {

    var validationResult = validateApplicant(model);

    if (validationResult.length > 0) {
      return Promise.reject(validationResult);
    }

    const checkCOuntry = await ValidateCountry(model.countryOfOrigin);

    if (!checkCOuntry) {
      return Promise.reject("country not found");
    }

    const param: ApplicantInsertRequest = {
      address: model.address,
      age: model.age,
      countryOfOrigin: model.countryOfOrigin,
      eMailAddress: model.eMailAddress,
      familyName: model.familyName,
      name: model.name,
      hired: model.hired
    }

    const result = await apiService.postAsync<ApplicantInsertRequest, Applicant>({ entityName: 'applicant', actionName: '', data: param });
    return result;
  }
  catch (error) {
    console.log(error);
    return Promise.reject(error.response.data.errors ?? error.response.data.Message)
  }
}


export const applicantService = {
  getApplicant,
  deleteApplicant,
  updateApplicant,
  insertApplicant,
  getAllApplicants,
  ValidateCountry
}
