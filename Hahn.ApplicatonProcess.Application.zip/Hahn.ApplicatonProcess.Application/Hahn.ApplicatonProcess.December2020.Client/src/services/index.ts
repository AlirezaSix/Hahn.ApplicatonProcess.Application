import {applicantService} from './applicantService';

export {
  applicantService
}
