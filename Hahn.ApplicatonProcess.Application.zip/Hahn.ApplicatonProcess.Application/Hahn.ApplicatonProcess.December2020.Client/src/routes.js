import { PLATFORM } from 'aurelia-pal';
var todoCategory = {
    title: 'Applicant',
};
export var routes = [
    { route: '', redirect: 'list' },
    { settings: { category: todoCategory }, route: 'list', moduleId: PLATFORM.moduleName('./pages/applicant/list'), name: 'list', title: 'Applicant list', nav: true },
    { settings: { category: todoCategory }, route: 'add', moduleId: PLATFORM.moduleName('./pages/applicant/edit'), name: 'add', title: 'Add Applicant', nav: true },
    { route: 'edit', moduleId: PLATFORM.moduleName('./pages/applicant/edit'), name: 'edit', title: 'Edit Aplicant' },
];
//# sourceMappingURL=routes.js.map